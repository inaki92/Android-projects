package com.example.inaki.thirdassesmentapi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.inaki.thirdassesmentapi.Adapter.DataAdapter;
import com.example.inaki.thirdassesmentapi.Network.RequestInterface;
import com.example.inaki.thirdassesmentapi.data.Item;
import com.example.inaki.thirdassesmentapi.data.Objects;
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;

import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    public static final String BASE_URL = "http://feature-code-test.skylark-cms.qa.aws.ostmodern.co.uk:8000/";

    private RecyclerView mRecyclerView;
    private DataAdapter mAdapter;
    private CompositeDisposable mCompositeDisposable;
    private Objects mListApiArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mCompositeDisposable = new CompositeDisposable();
        initRecyclerView();
        loadJSON();
    }

    private void initRecyclerView(){

        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        mRecyclerView.setLayoutManager(layoutManager);
    }

    private void loadJSON(){

        RequestInterface requestInterface = new Retrofit.Builder().baseUrl(BASE_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create()).addConverterFactory(GsonConverterFactory.create())
                .build().create(RequestInterface.class);

        mCompositeDisposable.add(requestInterface.register().observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io()).subscribe(this::handleResponse,this::handleError));
    }

    private void handleResponse(Objects ApiModelList){

        mListApiArrayList = ApiModelList;
        mAdapter = new DataAdapter(mListApiArrayList.getObjects());
        mRecyclerView.setAdapter(mAdapter);
    }

    private void handleError(Throwable error){

        Toast.makeText(this, "Error "+ error.getLocalizedMessage(),Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mCompositeDisposable.clear();
    }

}

