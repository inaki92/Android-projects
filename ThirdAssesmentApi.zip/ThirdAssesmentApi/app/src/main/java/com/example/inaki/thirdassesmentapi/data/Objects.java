package com.example.inaki.thirdassesmentapi.data;

import java.util.List;

public class Objects
{
    private Item[] objects;

    public Item[] getObjects ()
    {
        return objects;
    }

    public void setObjects (Item[] objects)
    {
        this.objects = objects;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [objects = "+objects+"]";
    }
}
