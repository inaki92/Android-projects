package com.example.inaki.thirdassesmentapi.Network;

import com.example.inaki.thirdassesmentapi.data.Objects;

import retrofit2.http.GET;
import io.reactivex.Observable;

public interface RequestInterface {
    @GET("api/sets/")
    Observable<Objects> register();

}
