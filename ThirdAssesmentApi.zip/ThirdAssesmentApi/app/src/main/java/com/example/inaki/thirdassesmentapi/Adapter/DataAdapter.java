package com.example.inaki.thirdassesmentapi.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.inaki.thirdassesmentapi.R;
import com.example.inaki.thirdassesmentapi.data.Item;
import com.example.inaki.thirdassesmentapi.data.Objects;
import com.squareup.picasso.Picasso;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {

    private Item[] mListApi;
    //private ImageView mImage;

    public DataAdapter (Item[] ApiList){mListApi = ApiList;}

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_recycler,viewGroup,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DataAdapter.ViewHolder holder, int i) {

        holder.mTvName.setText(mListApi[i].getTitle());
        holder.mTvInstructions.setText(mListApi[i].getBody());
        //holder.mTvPrice.setText(mListApi.get(i).getPrice().toString());

        //Picasso.get().load(mListApi[i].getTempImage())
                //.resize(80, 140).centerCrop().into(holder.mImage);

    }

    @Override
    public int getItemCount() {
        return mListApi.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView mTvName,mTvInstructions,mTvPrice;
        private ImageView mImage;

        public ViewHolder(View itemView) {
            super(itemView);

            mTvName = itemView.findViewById(R.id.tv_name);
            mTvInstructions = itemView.findViewById(R.id.tv_instructions);
            mTvPrice = itemView.findViewById(R.id.tv_price);
            mImage = itemView.findViewById(R.id.imageView);
        }
    }
}

