package com.example.inaki.createanaccount.Entity;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.media.Image;

@Entity
public class customerTable {

    @PrimaryKey(autoGenerate = true)
    int _id;

    @ColumnInfo(name = "CustName")
    private String CustName;

    @ColumnInfo(name= "CustCountry")
    private String CustCountry;

    @ColumnInfo(name = "CustPassword")
    private String CustPassword;

    @ColumnInfo(name = "CustUsername")
    private String CustUsername;

    @ColumnInfo(name = "CustAge")
    private String CustAge;

    @ColumnInfo(name = "CustGender")
    private String CustGender;

    //@ColumnInfo(name = "CustBirth")
    //private String CustBirth;

    @ColumnInfo(name = "CustAddress")
    private String CustAddress;

    @ColumnInfo(name = "CustPhoto")
    private int CustPhoto;


    public int get_id() {
        return _id;
    }
    public void set_id(int _id) {
        this._id = _id;
    }

    public String getCustName() {
        return CustName;
    }
    public void setCustName(String custName) {
        CustName = custName;
    }

    public String getCustPassword() {
        return CustPassword;
    }
    public void setCustPassword(String custPassword) {
        CustPassword = custPassword;
    }

    public String getCustUsername() {
        return CustUsername;
    }
    public void setCustUsername(String custUsername) {
        CustUsername = custUsername;
    }

    public String getCustGender() {
        return CustGender;
    }
    public void setCustGender(String custGender) {
        CustGender = custGender;
    }

    public String getCustCountry() {
        return CustCountry;
    }
    public void setCustCountry(String custCountry) {
        CustCountry = custCountry;
    }

    public String getCustAddress() {
        return CustAddress;
    }
    public void setCustAddress(String custAddress) {
        CustAddress = custAddress;
    }

    //public String getCustBirth() {
      //  return CustBirth;
    //}
    //public void getCustBirth(String custBirth) {
      //  CustBirth = custBirth;
    //}

    public String getCustAge(){return CustAge;}
    public void setCustAge(String custAge){CustAge = custAge;}

    public int getCustPhoto() {
        return CustPhoto;
    }
    public void setCustPhoto(int custPhoto) {
        CustPhoto = custPhoto;
    }

}
