package com.example.inaki.createanaccount;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;
import com.example.inaki.createanaccount.Entity.customerTable;
import com.example.inaki.createanaccount.database.DatabaseClient;

import java.util.Calendar;

public class UserData extends AppCompatActivity {

    private EditText etName, etPass, etUser, etAddress, etAge;
    private EditText etDate;
    private ImageView photo;
    private Button upPhoto;
    private Spinner spCountry;
    private RadioButton etfemale, etmale, etnot;

    //private int day,month,year;
    //private int dayFinal,monthFinal,yearFinal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_data);

        etName = findViewById(R.id.etName);
        etUser = findViewById(R.id.etUser);
        etPass = findViewById(R.id.etPass);
        etAddress = findViewById(R.id.edAddress);
        etDate = findViewById(R.id.etBirth);
        etAge = findViewById(R.id.numAge);
        photo = findViewById(R.id.photoView);
        upPhoto = findViewById(R.id.btnFoto);
        spCountry = findViewById(R.id.spCountry);
        etfemale = findViewById(R.id.rdFemale);
        etmale = findViewById(R.id.rdMale);
        etnot = findViewById(R.id.rdNot);



        //Take a photo
        upPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(in,0);
            }
        });

        //Crear el array de string en el archivo strings.xml
        //Creating an Array   Creando despliegue de paises con spinners
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.country_array, android.R.layout.simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCountry.setAdapter(adapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bitmap = (Bitmap)data.getExtras().get("data");
        photo.setImageBitmap(bitmap);
    }

    public void saveUser(View view){
        final String name = etName.getText().toString();
        final String user = etUser.getText().toString();
        final String pass = etPass.getText().toString();
        final String address = etAddress.getText().toString();
        final String country = spCountry.getSelectedItem().toString();
        final String gender;
        final String age = etAge.getText().toString();

        if(etmale.isChecked()){
            gender = etmale.getText().toString();
        }else if (etfemale.isChecked()){
            gender = etfemale.getText().toString();
        }else if (etnot.isChecked()){
            gender = etnot.getText().toString();
        }else{
            gender = "Not Selected";
        }

        class SaveData extends AsyncTask<Void, Void, Void>{
            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                Toast.makeText(UserData.this, "User saved", Toast.LENGTH_SHORT).show();
            }

            @Override
            protected Void doInBackground(Void... voids) {
                //Create object of the entity
                customerTable cTable = new customerTable();
                cTable.setCustName(name);
                cTable.setCustUsername(user);
                cTable.setCustPassword(pass);
                cTable.setCustCountry(country);
                cTable.setCustGender(gender);
                cTable.setCustAddress(address);
                cTable.setCustAge(age);

                DatabaseClient.getInstance(getApplicationContext()).getAppDatabase().iCustomerDAO().insertCustomer(cTable);
                return null;
            }
        }

        SaveData sData = new SaveData();
        sData.execute();

        Intent intent = new Intent(this,CustomerList.class);
        startActivity(intent);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }
}
