package com.example.inaki.createanaccount.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.example.inaki.createanaccount.Entity.customerTable;

import java.util.List;

@Dao
public interface ICustomerDAO {

    @Query("SELECT * FROM customertable")
    List<customerTable> getAllCustomers();

    @Insert
    void insertCustomer(customerTable customerTable);

    @Delete
    void deleteCustomer(customerTable customerTable);

    @Update
    void updateCustomer(customerTable customerTable);
}
