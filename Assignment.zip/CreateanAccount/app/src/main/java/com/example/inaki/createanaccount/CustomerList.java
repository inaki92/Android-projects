package com.example.inaki.createanaccount;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.example.inaki.createanaccount.Entity.customerTable;
import com.example.inaki.createanaccount.adapters.NameAdapter;
import com.example.inaki.createanaccount.database.DatabaseClient;

import java.util.List;

public class CustomerList extends AppCompatActivity {

    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_list);

        recyclerView = findViewById(R.id.rvCustomer);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        class ReadCustomers extends AsyncTask<Void, Void, List<customerTable>>{

            @Override
            protected void onPostExecute(List<customerTable> customerTables){
                super.onPostExecute(customerTables);
                Log.i("Customer", customerTables.get(0).getCustName());
                recyclerView.setAdapter(new NameAdapter(getApplicationContext(), R.layout.item_customer, customerTables));
                //IMPLEMENTAR RECYCLER Y ADAPTER
            }
            @Override
            protected List<customerTable> doInBackground(Void... voids) {

                List<customerTable>customerTables = DatabaseClient.getInstance(getApplicationContext()).getAppDatabase().iCustomerDAO().getAllCustomers();

                return customerTables;
            }
        }

        ReadCustomers readCustomers = new ReadCustomers();
        readCustomers.execute();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }
}
