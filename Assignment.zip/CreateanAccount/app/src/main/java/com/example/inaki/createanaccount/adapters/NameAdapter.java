package com.example.inaki.createanaccount.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.inaki.createanaccount.Entity.customerTable;
import com.example.inaki.createanaccount.R;

import java.util.List;

public class NameAdapter extends RecyclerView.Adapter<NameAdapter.ViewHolder> {

    private Context applicationContext;
    private int item_customer;
    private List<customerTable>customerTables;
    public NameAdapter(Context applicationContext, int item_customer, List<customerTable> customerTables) {
        this.applicationContext = applicationContext;
        this.item_customer = item_customer;
        this.customerTables = customerTables;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(item_customer,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        holder.name.setText(customerTables.get(i).getCustName());
        holder.username.setText(customerTables.get(i).getCustUsername());
        holder.address.setText(customerTables.get(i).getCustAddress());
        holder.gender.setText(customerTables.get(i).getCustGender());
        holder.country.setText(customerTables.get(i).getCustCountry());

        //holder.photo.setImageResource(customerTables.get(i).getImage()); FALTA GUARDAR IMAGEN
    }

    @Override
    public int getItemCount() {
        return customerTables.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView name, username, address, country, gender, date;
        private ImageView photo;

        public ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tvName);
            username = itemView.findViewById(R.id.tvUsername);
            address = itemView.findViewById(R.id.tvAddress);
            country = itemView.findViewById(R.id.tvCountry);
            gender = itemView.findViewById(R.id.tvGender);
            date = itemView.findViewById(R.id.tvDate);
            photo = itemView.findViewById(R.id.photoView);
        }
    }
}
