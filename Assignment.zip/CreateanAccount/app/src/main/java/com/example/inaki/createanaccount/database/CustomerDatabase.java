package com.example.inaki.createanaccount.database;


import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;
import com.example.inaki.createanaccount.Entity.customerTable;

import com.example.inaki.createanaccount.dao.ICustomerDAO;

@Database(entities = {customerTable.class}, version = 1)
public abstract class CustomerDatabase extends RoomDatabase {
    public abstract ICustomerDAO iCustomerDAO();
}
