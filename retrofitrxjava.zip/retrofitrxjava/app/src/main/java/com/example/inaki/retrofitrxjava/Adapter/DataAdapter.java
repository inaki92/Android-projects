package com.example.inaki.retrofitrxjava.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.inaki.retrofitrxjava.R;
import com.example.inaki.retrofitrxjava.model.Android;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {

    private ArrayList<Android> mAndroidList;

    public DataAdapter(ArrayList<Android> androidList){
        mAndroidList = androidList;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycler_row,viewGroup,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {

        holder.mTvName.setText(mAndroidList.get(i).getName());
        holder.mTvApi.setText(mAndroidList.get(i).getApi());
        holder.mTvVersion.setText(mAndroidList.get(i).getVer());
    }

    @Override
    public int getItemCount() {
        return mAndroidList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView mTvName,mTvVersion,mTvApi;
        public ViewHolder(View itemView) {
            super(itemView);

            mTvName = itemView.findViewById(R.id.tv_name);
            mTvVersion = itemView.findViewById(R.id.tv_version);
            mTvApi = itemView.findViewById(R.id.tv_api_level);
        }
    }
}
