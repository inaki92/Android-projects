package com.example.inaki.retrofitrxjava.model;

public class Android {

    private String ver;
    private String name;
    private String api;

    public String getVer(){ return ver; }

    public String getName(){
        return name;
    }

    public String getApi(){
        return api;
    }
}
