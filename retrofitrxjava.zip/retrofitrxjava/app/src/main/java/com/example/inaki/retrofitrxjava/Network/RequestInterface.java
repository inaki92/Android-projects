package com.example.inaki.retrofitrxjava.Network;

import com.example.inaki.retrofitrxjava.model.Android;

import java.util.List;
//import java.util.Observable;

import retrofit2.http.GET;
import io.reactivex.Observable;

public interface RequestInterface {
    @GET("android/jsonarray/")
    Observable<List<Android>>register();
}
