package com.example.inaki.passingdataassessment;

import android.content.Intent;
import android.os.Parcel;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.inaki.passingdataassessment.Books.Book;

public class BookActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        TextView mBkTitle = findViewById(R.id.bk_title);
        TextView mBkAuthor = findViewById(R.id.bk_author);

        Intent intent = getIntent();
        Book book = intent.getParcelableExtra("Book");

        mBkTitle.setText("Title:" + book.getTitle());
        mBkAuthor.setText("Author:" + book.getAuthor());
    }
}
