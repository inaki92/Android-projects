package com.google.codelabs.mdc.kotlin.shipping

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class ShippingInfoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.shipping_info_activity)
    }
}
